# XeLatex-Template

XeLatex-Template is for the template of XeLatex.

## Status

### 1. Beamer

* √ Basic Framework
* √ Various Options
* √ Some Overlays
*   More Feature

### 2. Article

* √ Basic Framework
* √ Chinese Support
*   More Feature

### 3. Book

* √ Basic Framework
*   More Feature

### 4. Report

* √ Basic Framework
*   More Feature

### 5. Letter

* ToDo

***
Yinyanghu, 2013
